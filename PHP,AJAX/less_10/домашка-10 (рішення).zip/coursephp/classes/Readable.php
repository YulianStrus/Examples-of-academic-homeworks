<?php

interface Readable
{
    public function getSrcId();
    public function getContent();
    public function getSrcInfo();
}